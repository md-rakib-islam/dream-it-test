import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  tabs: [
    { id: 1, name: "All" },
    { id: 2, name: "Attraction Tours" },
    { id: 3, name: "Day Tours" },
    { id: 4, name: "Multi-Day Tours" },
    // { id: 4, name: "Holyday Rentals", icon: "icon-home" },
    // { id: 5, name: "Car", icon: "icon-car" },
    // { id: 6, name: "Cruise", icon: "icon-yatch" },
    // { id: 7, name: "Flights", icon: "icon-tickets" },
  ],
  currentTab: "All",
};

export const findPlaceSlice = createSlice({
  name: "find-place",
  initialState,
  reducers: {
    addCurrentTab: (state, { payload }) => {
      state.currentTab = payload;
    },
  },
});

export const { addCurrentTab } = findPlaceSlice.actions;
export default findPlaceSlice.reducer;
