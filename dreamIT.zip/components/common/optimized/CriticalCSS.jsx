"use client";

import { useEffect } from "react";

const CriticalCSS = () => {
  useEffect(() => {
    // Load non-critical CSS after page load
    const loadNonCriticalCSS = () => {
      const links = [
        "/styles/index.scss",
        "https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css",
      ];

      links.forEach((href) => {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = href;
        link.media = "print";
        link.onload = function () {
          this.media = "all";
        };
        document.head.appendChild(link);
      });
    };

    // Load after a short delay to prioritize critical rendering
    const timer = setTimeout(loadNonCriticalCSS, 100);

    return () => clearTimeout(timer);
  }, []);

  return null;
};

export default CriticalCSS;
