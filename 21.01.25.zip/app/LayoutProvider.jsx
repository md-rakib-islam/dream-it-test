"use client";

import React, { createContext, useState, useEffect, useCallback } from "react";

// Create Context
export const LayoutContext = createContext();

export default function LayoutProvider({ data, children }) {
  const [selectedCurrency, setSelectedCurrency] = useState({
    id: 10,
    name: "Euro",
    currency: "EUR",
    symbol: "€",
  });
  const [filteredTours, setFilteredTours] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedDuration, setSelectedDuration] = useState("");
  const [layoutData, setLayoutData] = useState(data);

  const updateCurrency = useCallback((currency) => {
    setSelectedCurrency(currency);
  }, []);

  const updateLayoutData = useCallback((newData) => {
    setLayoutData((prevData) => ({ ...prevData, ...newData }));
  }, []);

  useEffect(() => {
    // This effect will run whenever the data prop changes
    setLayoutData(data);
  }, [data]);

  return (
    <LayoutContext.Provider
      value={{
        ...layoutData,
        selectedCurrency,
        updateCurrency,
        filteredTours,
        setFilteredTours,
        setSelectedCategory,
        selectedCategory,
        selectedDuration,
        setSelectedDuration,
        updateLayoutData,
      }}
    >
      {children}
    </LayoutContext.Provider>
  );
}
